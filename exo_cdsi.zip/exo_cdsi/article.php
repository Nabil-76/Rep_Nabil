<?php
if(!isset($_GET['id']) OR !is_numeric($_GET['id']))
    header('Location: index.php');
else
{
    extract($_GET);
    $id = strip_tags($id);

    require_once('config/fonctions.php');

    $article = getArticle($id);
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?= $article->titre ?></title>
</head>
<body>
    <h1><?= $article->Titre ?></h1>
    <p><?= $article->Contenu ?></p>
    <hr />

    <form action="article.php?id=<?= $article->id ?>" methode="post">
        <p><label for="auteur">Pseudo :</label><br />
        <input type="text" name="auteur" id="auteur" /></p>
        <p><label for="commentaire">Commentaire :</label><br />
        <textarea name="commentaire" id="commentaire" cols="30" rows="8"></textarea></p>
        <button type="submit">Envoye</button>
    </form>
</body>
</html>