<?php

require_once('config/fonctions.php');

$articles = getArticles();
?>

<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <title>Mon Blog</title>
</head>

<body>
    <h1>Articles : </h1>

    <?php foreach($articles as $article): ?>
        <h2><?= $article->titre ?></h2>
        <a href="article.php?id=<?= $article->id ?>">Lire la suite</a>
    <?php endforeach; ?>

</body>

</html>