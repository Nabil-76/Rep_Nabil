<?php
// fonction qui recupere tous les articles
function getArticles()
{
    require('config/connect.php');
    $req = $bdd->prepare('SELECT id, titre FROM articles ORDER BY id DESC');
    $req->execute();
    $date = $req->fetchAll(PDO::FETCH_OBJ);
    return $date;
    $req->closeCursor();
}
//Fonction qui recupere un article
function getArticle($id)
{
    require('config/connect.php');
    $req = $bdd->prepare('SELECT * FROM articles WHERE id = ?');
    $req->execute(array($id));
    if($req->rowCount() == 1)
    {
        $date = $req->fetch(PDO::FETCH_OBJ);
        return $date;
    }
    else
        header('Location: index.php');
}