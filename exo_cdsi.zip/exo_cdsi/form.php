
<!DOCTYPE html>
<html lang="fr-FR">

<head>
    <meta charset="UTF-8" />
    <title>Ma Page</title>
</head>

<body>
    <h1>Mon blog</h1>
</body>

</html>